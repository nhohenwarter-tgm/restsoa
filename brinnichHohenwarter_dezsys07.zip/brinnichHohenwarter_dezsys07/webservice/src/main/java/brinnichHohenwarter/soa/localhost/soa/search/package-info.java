//
// Diese Datei wurde mit der JavaTM Architecture for XML Binding(JAXB) Reference Implementation, v2.2.7 generiert 
// Siehe <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Änderungen an dieser Datei gehen bei einer Neukompilierung des Quellschemas verloren. 
// Generiert: 2016.01.02 um 01:58:20 PM CET 
//

@javax.xml.bind.annotation.XmlSchema(namespace = "http://localhost/soa/search", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package brinnichHohenwarter.soa.localhost.soa.search;
