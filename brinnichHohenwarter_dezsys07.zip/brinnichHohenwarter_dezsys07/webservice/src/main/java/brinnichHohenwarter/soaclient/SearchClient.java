package brinnichHohenwarter.soaclient;

/**
 * Created by niklas on 02.01.16.
 */
public class SearchClient {
}
